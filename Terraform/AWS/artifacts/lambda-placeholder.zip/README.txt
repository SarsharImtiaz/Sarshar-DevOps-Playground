Lambda placeholder package

This ZIP is only for Terraform/Lambda resource creation during infrastructure bootstrap.
It is NOT a real deployable .NET Lambda package.
Replace it later with the real application package in the same S3 key.

Expected next step:
- upload the real ZIP to the same S3 object key
- run terraform apply again if needed
